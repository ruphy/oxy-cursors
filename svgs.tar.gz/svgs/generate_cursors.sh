#!/bin/bash

colors="blue yellow brown green violet red purple navy sea_blue emerald hot_orange"

mkdir -p pngs

for color in $colors; do

echo "Generating PNGs for the color: $color"

mkdir pngs/$color;
cp $color/*.svg pngs/$color/
cd pngs/$color/

for icon in $(ls *.svg); do
inkscape --without-gui --export-png=$( echo $icon | sed s/.svg// ).png --export-dpi=72 --export-background-opacity=0 --export-width=$SIZE --export-height=$SIZE $icon > /dev/null
done


done




